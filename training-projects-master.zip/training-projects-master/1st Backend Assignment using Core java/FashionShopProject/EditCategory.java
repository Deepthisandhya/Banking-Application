package FashionShopProject;

import java.util.Scanner;

import org.apache.commons.lang3.ArrayUtils;

public class EditCategory {
	ExcistingCategoryList catlist=new ExcistingCategoryList();
	MainFile maindisplay=new MainFile();


public void EditCategoryList(int option) {
	try {
	if(option==1) {
		Scanner delmencat=new Scanner(System.in);
	      System.out.println("Select the option to edit from Mens List:");
	      for(int i=0;i<catlist.Mendresstypes.size();i++) {
		      System.out.print("          "+(i+1)+" "+catlist.Mendresstypes.get(i));
		      System.out.println("                        Rs. "+catlist.Menprices.get(i));
	      }
	      System.out.println();
	      int delmendress=delmencat.nextInt();
			
	      Scanner edidress=new Scanner(System.in);
	      System.out.println("Edit the dress option here: ");
	      String edidressval=edidress.nextLine();
	      Scanner ediprice=new Scanner(System.in);
	      System.out.println("Edit the amount  here: ");
	      int edipriceval=ediprice.nextInt();
	      
	      int index1=delmendress-1;
	      indexmenselected(index1,option,edidressval,edipriceval);
	}
	else if(option==2) {
		Scanner delwomencat=new Scanner(System.in);
	      System.out.println("Select the option to edit from Womens List:");
	      for(int i=0;i<catlist.Womendresstypes.size();i++) {
		      System.out.print("          "+(i+1)+" "+catlist.Womendresstypes.get(i));
		      System.out.println("                        Rs. "+catlist.Womenprices.get(i));
	      }
	      int delwomendress=delwomencat.nextInt();
			
	      Scanner edidress=new Scanner(System.in);
	      System.out.println("Edit the dress option here: ");
	      String edidressval=edidress.nextLine();
	      Scanner ediprice=new Scanner(System.in);
	      System.out.println("Edit the amount  here: ");
	      int edipriceval=ediprice.nextInt();
	      
	      int index1=delwomendress-1;
	      System.out.println(index1);
	      //newdressarray(dress);
	      catlist.Womendresstypes.remove(index1);
	      catlist.Womendresstypes.add(index1, edidressval);
	      catlist.Womenprices.add(index1, edipriceval);

	      maindisplay.NewList(catlist.Womendresstypes,catlist.Womenprices,option);


	}
	else {
	      System.out.println();

	      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
	      System.out.println();

		CategoryOption catoption= new CategoryOption();
		catoption.Subcategoryedit();
	}
	}
	catch(Exception e) {
		System.out.println();

	      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
	      System.out.println();

		CategoryOption catoption= new CategoryOption();
		catoption.Subcategoryedit();
	}
}

	public void indexmenselected(int index1,int option,String edidressval,int edipriceval) {
try {
	      String EditValueSelected=catlist.Mendresstypes.get(index1);
	      if(catlist.Mendresstypes.contains(EditValueSelected)){
	    	  catlist.Mendresstypes.remove(index1);
		      catlist.Mendresstypes.add(index1, edidressval);
		      catlist.Menprices.add(index1, edipriceval);

		      maindisplay.NewList(catlist.Mendresstypes,catlist.Menprices,option);  
	      }
	      else {
	    	  
System.out.println();

	      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
	      System.out.println();
	    	  EditCategoryList(option);
	    	 
	      }
}
	   catch(Exception e) {
		   System.out.println();

		      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
		      System.out.println();
		    	  EditCategoryList(option);
		    	 
		      }
	   }
	
	
	public void indexwomenselected(int index1,int option,String edidressval,int edipriceval) {
//	      System.out.println(index1);
	      //newdressarray(dress);
	      String EditValueSelected=catlist.Womendresstypes.get(index1);
	      if(catlist.Womendresstypes.contains(EditValueSelected)){
	    	  catlist.Womendresstypes.remove(index1);
		      catlist.Womendresstypes.add(index1, edidressval);
		      catlist.Womenprices.add(index1, edipriceval);

		      maindisplay.NewList(catlist.Womendresstypes,catlist.Womenprices,option);  
	      }
	      else {
	    	  
	System.out.println();

	      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
	      System.out.println();

	    	  EditCategoryList(option);
	    	 
	      }
	      
	
	}
	
}
