package FashionShopProject;

import java.util.ArrayList;
import java.util.Arrays;

public class ExcistingCategoryList {
	ArrayList<String> mainheadigs=new ArrayList<String>(Arrays.asList("DRESS MATERIALS","PRICE"));
	ArrayList<String> sex=new ArrayList<String>(Arrays.asList("MEN","WOMEN"));
    ArrayList<String> Mendresstypes=new ArrayList<String>(Arrays.asList("jean","jupa","Shirt","shorts"));
	ArrayList<Integer> Menprices=new ArrayList<Integer>(Arrays.asList(500,600,700,800));
	ArrayList<String> Womendresstypes=new ArrayList<String>(Arrays.asList("Kurti","saree","jean","Night dress"));
	ArrayList<Integer> Womenprices=new ArrayList<Integer>(Arrays.asList(500,600,700,800));

	
	
}
