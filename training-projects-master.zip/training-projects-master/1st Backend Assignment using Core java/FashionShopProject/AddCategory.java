package FashionShopProject;

import java.util.Scanner;

public class AddCategory{
	ExcistingCategoryList catlist=new ExcistingCategoryList();
	MainFile maindisplay=new MainFile();


	public void AddCategoryList(int option) {
		try {
	if(option==1) {
		
		Scanner newMencategory=new Scanner(System.in);
	      System.out.println("Enter the new dress category   (eg: Blazer,T-shirt):");
	      String newMaledresscategory=newMencategory.nextLine();
	      
	      
     
	      catlist.Mendresstypes.add(newMaledresscategory);

	      
	      
	      Scanner newMencategoryprice=new Scanner(System.in);
	      System.out.println("Enter the price   (eg: 1500):");
	      int newMencategoryprice1=newMencategoryprice.nextInt();
	      
	      catlist.Menprices.add(newMencategoryprice1);

	      maindisplay.NewList(catlist.Mendresstypes,catlist.Menprices,option);
	      
	      

		}else if(option==2) {
	      
		     

	      
	      Scanner newWomencategory=new Scanner(System.in);
	      System.out.println("Enter the new dress category   (eg: shrug,lehenga):");
	      String newdresscategory=newWomencategory.nextLine();
	      
	      
     
	      catlist.Womendresstypes.add(newdresscategory);

	      
	      
	      Scanner newWomencategoryprice=new Scanner(System.in);
	      System.out.println("Enter the price   (eg: 1500):");
	      int newWomencategoryprice1=newWomencategoryprice.nextInt();
	      
	      catlist.Womenprices.add(newWomencategoryprice1);

	      maindisplay.NewList(catlist.Womendresstypes,catlist.Womenprices,option);
	      
	      
		}
		else {
	System.out.println();

	      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
	      System.out.println();

			CategoryOption catoption= new CategoryOption();
			catoption.Subcategoryadd();
		}
		}
		catch(Exception e) {
			System.out.println();

		      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
		      System.out.println();

				CategoryOption catoption= new CategoryOption();
				catoption.Subcategoryadd();
		}



}
}
