package FashionShopProject;

import java.util.Scanner;

public class CategoryOption {
	ExcistingCategoryList catlist=new ExcistingCategoryList();
	AddCategory addoptions=new AddCategory();

	public void sexcategory() {

  		String addCat ="Add Category";
  		String editCat="Edit Category";
  		String delCat="Delete Category";
	      String quit="Quit";
	      System.out.println();
	      System.out.println();

  		System.out.println("Please select an option to perform Add,edit or Delete the above catalog  (eg: 1/2/3):");
	      System.out.println("1) "+addCat);
	      System.out.println("2) "+editCat);
	      System.out.println("3) "+delCat);
		System.out.println("4) "+quit);
	      System.out.println("Enter your option here:");

		Scanner firstchoice=new Scanner(System.in);
		int firstchoiceselected=firstchoice.nextInt();
		listofoptions(firstchoiceselected);
		
	}
	public void listofoptions(int firstchoiceselected) {
		try {
	     switch(firstchoiceselected){
	     case(1):
	    	Subcategoryadd();
	     	
	     
	     break;
	     case(2):
	    	 Subcategoryedit();
	     break;
	     case(3):
	    	 Subcategorydelete();
	     break;
	     case(4):
	    	 System.out.println("********* Thank You *************"); 
	     break;
	     default:
	    	 System.out.println();

		      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
		      System.out.println();
	    	 sexcategory();
	     
	     
	     }
		}
		catch(Exception e) {
			System.out.println();

		      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
		      System.out.println();
	    	 sexcategory();
		}
	}

	public void Subcategorydelete() {
			System.out.println("Select the category:");
			System.out.println("   1)" +catlist.sex.get(0));
			System.out.println("   2)" +catlist.sex.get(1));
			Scanner secondchoice=new Scanner(System.in);
		      System.out.println("Enter your option here   (eg: 1/2/3):");
		      int secondchoiceselected=secondchoice.nextInt();
		      DeleteCategory deleteoption=new DeleteCategory();
		      deleteoption.DeleteCategoryList(secondchoiceselected);
		
	
	}

	public void Subcategoryedit() {
		
			System.out.println("Select the category:");
			System.out.println("   1)" +catlist.sex.get(0));
			System.out.println("   2)" +catlist.sex.get(1));
			Scanner secondchoice=new Scanner(System.in);
		      System.out.println("Enter your option here   (eg: 1/2/3):");
		      int secondchoiceselected=secondchoice.nextInt();
		      EditCategory editoption=new EditCategory();
		      editoption.EditCategoryList(secondchoiceselected);
		
	
	}

	public void Subcategoryadd() {

			
			System.out.println("Select the category:");
			System.out.println("   1)" +catlist.sex.get(0));
			System.out.println("   2)" +catlist.sex.get(1));
			Scanner secondchoice=new Scanner(System.in);
		      System.out.println("Enter your option here   (eg: 1/2/3):");
		      int secondchoiceselected=secondchoice.nextInt();
		      addoptions.AddCategoryList(secondchoiceselected);
			
	

	
	
	}
}
