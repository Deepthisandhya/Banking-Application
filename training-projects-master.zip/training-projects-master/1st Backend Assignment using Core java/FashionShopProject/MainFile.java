package FashionShopProject;

import java.util.ArrayList;

public class MainFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExistingList();
	}
	public static void ExistingList() {
			ExcistingCategoryList catlist=new ExcistingCategoryList();
		
	      

	  		System.out.print("**************** ");
	        System.out.println("The Fashion Store ****************");
	        System.out.println();
	        System.out.println("1. Dress Materials");
	        System.out.println("      i) "+catlist.sex.get(0));
	        System.out.print("          "+catlist.mainheadigs.get(0));
	        System.out.println("                 "+catlist.mainheadigs.get(1));

	      for(int i=0;i<catlist.Mendresstypes.size();i++) {
	      System.out.print("          "+(i+1)+" "+catlist.Mendresstypes.get(i));
	      System.out.println("                        Rs. "+catlist.Menprices.get(i));
	      
	      
	      } 
	      System.out.println();
	      System.out.println("      ii) "+catlist.sex.get(1));
	        System.out.print("          "+catlist.mainheadigs.get(0));
	        System.out.println("                  "+catlist.mainheadigs.get(1));

	      for(int i=0;i<catlist.Womendresstypes.size();i++) {
	      System.out.print("          "+(i+1)+" "+catlist.Womendresstypes.get(i));
	      System.out.println("                        Rs. "+catlist.Womenprices.get(i));
	            
	      
	      
		
		}
	      CategoryOption category=new CategoryOption();
	      category.sexcategory();
	}
		
	      public static void NewList(ArrayList<String> dresstypes,ArrayList<Integer> prices,int option) {
				ExcistingCategoryList catlist=new ExcistingCategoryList();
				
		      

		  		System.out.print("**************** ");
		        System.out.println("The Fashion Store ****************");
		        System.out.println();
		        System.out.println("1. Dress Materials");
		        if(option==1) {
		        	System.out.println("      i) "+catlist.sex.get(0));	
		        }
		        else if(option==2) {
		        	System.out.println("      ii) "+catlist.sex.get(1));
		        }
		        
		        System.out.print("         "+catlist.mainheadigs.get(0));
		        System.out.println("                 "+catlist.mainheadigs.get(1));

		      for(int i=0;i<dresstypes.size();i++) {
		      System.out.print("          "+(i+1)+" "+dresstypes.get(i));
		      System.out.println("                        Rs. "+prices.get(i));
		      
		      
		      } 
		      CategoryOption category=new CategoryOption();
		      category.sexcategory();

	}

}
