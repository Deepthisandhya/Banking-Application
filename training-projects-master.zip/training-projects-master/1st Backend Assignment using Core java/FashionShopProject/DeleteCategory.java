package FashionShopProject;

import java.util.Scanner;

public class DeleteCategory {
	ExcistingCategoryList catlist=new ExcistingCategoryList();
	MainFile maindisplay=new MainFile();


public void DeleteCategoryList(int option) {
	try {
	if(option==1) {
		Scanner delmencat=new Scanner(System.in);
	      System.out.println("Select the option to delete from Mens List:");
	      for(int i=0;i<catlist.Mendresstypes.size();i++) {
		      System.out.print("          "+(i+1)+" "+catlist.Mendresstypes.get(i));
		      System.out.println("                        Rs. "+catlist.Menprices.get(i));
	      }
	      int delmendress=delmencat.nextInt();
	      
	      
	      
	      int index1=delmendress-1;
	      System.out.println(index1);
	      //newdressarray(dress);
	      catlist.Mendresstypes.remove(index1);
	      

	      maindisplay.NewList(catlist.Mendresstypes,catlist.Menprices,option);


	      
		}
	else if(option==2) {
		Scanner delwomencat=new Scanner(System.in);
	      System.out.println("Select the option to edit from Mens List:");
	      for(int i=0;i<catlist.Womendresstypes.size();i++) {
		      System.out.print("          "+(i+1)+" "+catlist.Womendresstypes.get(i));
		      System.out.println("                        Rs. "+catlist.Womenprices.get(i));
	      }
	     
	      int delwomendress=delwomencat.nextInt();
	      
	      
	      int index1=delwomendress-1;
	      System.out.println(index1);
	      //newdressarray(dress);
	      catlist.Womendresstypes.remove(index1);
	     

	      maindisplay.NewList(catlist.Womendresstypes,catlist.Womenprices,option);


	}
	else {
System.out.println();

	      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
	      System.out.println();

		CategoryOption catoption= new CategoryOption();
		catoption.Subcategoryadd();
	}
	}
	catch(Exception e) {
		System.out.println();

	      System.out.println("********* Sorry that is an invalid option.Let's try again *************");
	      System.out.println();

		CategoryOption catoption= new CategoryOption();
		catoption.Subcategoryadd();
	}
}
}
