package com.web.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class LibraryAdmin extends OperableEntity {

	@Id
	private int id;
	private String name;
	private String loginid;
	private String password;
	
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getLoginid() {
		return loginid;
	}
	public String getPassword() {
		return password;
	}
	@Override
	public String toString() {
		return "LibraryAdmin [id=" + id + ", name=" + name + ", loginid=" + loginid + ", password=" + password + "]";
	}
	
}
