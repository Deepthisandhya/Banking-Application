package com.web.service;


import java.util.List;

import com.web.db.DBManager;
import com.web.model.Book1;

public class BookService {

	private static DBManager dbManager;
	
	static {
		dbManager = DBManager.getDBManager();
	}
	
	public static boolean addNewBook(int id, String name, String author, double price) {
		
		Book1 book = new Book1();
		book.setId(id);
		book.setBookName(name);
		book.setAuthorName(author);
		book.setBookPrice(price);
		
		return dbManager.writeToDB(book);
	}
	public static List fetchBookList() {
		System.out.println(dbManager.readFromDB("Book1"));
		return dbManager.readFromDB("Book1");
	}
	
	public static List fetchBookListspecific(String name1) {
		List<Book1> l = fetchBookList();
		Book1 bookTofetch = null;
		for (Book1 book : l) {
			if(book.getBookName() == name1) {
				System.out.println(book.getId() + " :: " + name1);
				bookTofetch = book;
				break;
			}
		}
		int id = bookTofetch.getId();
		String name = bookTofetch.getBookName();
		String author = bookTofetch.getAuthorName();
		double price = bookTofetch.getBookPrice();
		
		Book1 book = new Book1();
		book.setId(id);
		book.setBookName(name);
		book.setAuthorName(author);
		book.setBookPrice(price);
		System.out.println(book);
//		System.out.println(dbManager.readFromDBSpecific(name1));
		return dbManager.readFromDBSpecific(name1);

	}
	
	public static boolean updateBook(int id, String name, String author, double price) {
		Book1 book = new Book1();
		book.setId(id);
		book.setBookName(name);
		book.setAuthorName(author);
		book.setBookPrice(price);
		
		return dbManager.writeToDB(book);
	}
	
	public static void deleteBook(int id) {
		List<Book1> l = fetchBookList();
		Book1 bookToDelete = null;
		for (Book1 book : l) {
			if(book.getId() == id) {
				System.out.println(book.getId() + " :: " + id);
				bookToDelete = book;
				break;
			}
		}
		String name = bookToDelete.getBookName();
		String author = bookToDelete.getAuthorName();
		double price = bookToDelete.getBookPrice();
		
		Book1 book = new Book1();
		book.setId(id);
		book.setBookName(name);
		book.setAuthorName(author);
		book.setBookPrice(price);
		
		dbManager.deleteFromDB(book);
	}
//	public static void main(String arg[]) {
//BookService bc=new BookService();
//bc.fetchBookListspecific("book2");
//	}
}
