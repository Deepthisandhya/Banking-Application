package com.web.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan({"com.web"})

public class WebConfig {
	// where is the view files located
		// what is the extension of the files / view technology
		
		@Bean
		public InternalResourceViewResolver viewResolver() {
			InternalResourceViewResolver irvr = new InternalResourceViewResolver();
			
			// let's say file called for view is: "file1"
			// setPrefix will be adding the part before this filename
			irvr.setPrefix("/WEB-INF/views/");	// this makes the filename: "/WEB-INF/views/file1"
			irvr.setSuffix(".jsp");	// this makes the filename: "/WEB-INF/views/file1.jsp"
			
			return irvr;
		}
}
