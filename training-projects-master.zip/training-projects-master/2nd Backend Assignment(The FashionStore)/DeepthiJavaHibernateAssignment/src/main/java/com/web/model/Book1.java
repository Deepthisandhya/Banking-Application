package com.web.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "Book")
public class Book1 extends OperableEntity {
	
	@Id
	public int id;
	public String bookName;
	public String authorName;
	public double bookPrice;
	
	public void setId(int id) {
		this.id = id;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	
	public int getId() {
		return id;
	}
	public String getBookName() {
		return bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	@Override
	public String toString() {
		return "Book1 [id=" + id + ", bookName=" + bookName + ", authorName=" + authorName + ", bookPrice=" + bookPrice
				+ "]";
	}
	
}
