package com.web.model;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class userdetails extends OperableEntity {
	
	@Id
	private String user_id;
	private String user_name;
	private String user_address;
	private String user_phno;
	private String user_password;
	
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public String getUser_phno() {
		return user_phno;
	}
	public void setUser_phno(String user_phno) {
		this.user_phno = user_phno;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	
	@Override
	public String toString() {
		return "userdetails [user_id=" + user_id + ", user_name=" + user_name + ", user_address=" + user_address + ", user_phno=" + user_phno + ", user_password=" + user_password + "]";
	}
	

}

