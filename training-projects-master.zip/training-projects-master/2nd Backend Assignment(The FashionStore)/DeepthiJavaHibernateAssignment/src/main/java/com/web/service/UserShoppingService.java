package com.web.service;


import java.util.HashMap;
import java.util.List;

import com.web.db.DBManager;

import com.web.model.userdetails;

public abstract class UserShoppingService {
private static DBManager dbManager;
static HashMap<String, String> userDetails = new HashMap<String, String>();

	static {
		dbManager = DBManager.getDBManager();
	}
	
	@SuppressWarnings("unchecked")
	public static HashMap<String, String> validateUser (String uname, String pwd) {
		
		boolean isValidLogin = false;
		userdetails userdet=null;
		
		List<userdetails> userList = dbManager.readFromDB("userdetails");


		for(userdetails la : userList) {
			if(la.getUser_id().equals(uname) && la.getUser_password().equals(pwd)) {
				isValidLogin = true;
				userdet = la;
				break;
			} else {
				isValidLogin = false;
			}
		}
		
		if(isValidLogin) {
			userDetails.put("ADMIN_NAME", userdet.getUser_name());
			System.out.println("user"+userDetails);
			return userDetails;
		}
		System.out.println("after if"+userDetails);
		return null;
		
		}
	

}


