package com.web.controller;


import java.awt.print.Book;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.service.BookService;
import com.web.service.UserShoppingService;


@Controller
public class UserShoppingController {
	
	@RequestMapping(value="/Userloginhomepage", method=RequestMethod.POST)
	public ModelAndView Userloginhomepage(HttpServletRequest request, HttpServletResponse response) {
		
		String username = request.getParameter("uname");
		String password = request.getParameter("pwd");

		if(username.length()==0 || password.length()==0)  {
			
			ModelAndView mv = new ModelAndView();
			mv.addObject("u_error", "Please enter the Username");
			mv.setViewName("Usersignin1");
			mv.addObject("p_error", "Please enter the Password");
		mv.setViewName("Usersignin1");
			
			return mv;	
			
		}
//		ModelAndView mv = new ModelAndView();
//
//		return mv;	

		
		else {
		Map<String, String> userDetails = UserShoppingService.validateUser(username, password);
		
		try {
			String userFullName = userDetails.get("ADMIN_NAME");

			request.getSession().setAttribute("USER_FULL_NAME", userFullName);
			List<Book> listOfBooks = BookService.fetchBookList();
			System.out.println(listOfBooks);
			ModelAndView mv = new ModelAndView();
			mv.addObject("username",userFullName);
			mv.addObject("book_list", listOfBooks);
			
			mv.setViewName("userhome1");	
//			mv.setViewName("bookhome");
			
			return mv;
		} catch (Exception e) {
			ModelAndView mv = new ModelAndView();
			mv.addObject("msg", "Username/Password is wrong");
			mv.setViewName("Usersignin1");
			
			return mv;
		}
		
		}
			
	}
	
	
}
