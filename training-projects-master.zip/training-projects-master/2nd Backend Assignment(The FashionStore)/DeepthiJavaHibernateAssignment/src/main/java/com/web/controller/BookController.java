package com.web.controller;



import java.awt.print.Book;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.web.db.DBManager;
import com.web.model.cartmodel;
import com.web.model.userdetails;
import com.web.service.BookService;
import com.web.service.UserService;
import com.web.service.UserShoppingService;
import com.web.service.cartservice;


@Controller
public class BookController {
	
	@RequestMapping("/addbook")
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
	
		boolean isBookAdded = BookService.addNewBook(Integer.parseInt(request.getParameter("bookid")), request.getParameter("bookname"), request.getParameter("author"), Double.parseDouble(request.getParameter("bookprice")));
		
		if (isBookAdded)
			mv.addObject("sucess", "Book record added successfully");
		else
			mv.addObject("failure", "Unable to add book record");

		mv.setViewName("bookhome");
		
		return mv;
	}
	

	@RequestMapping("/fetchbook")
	public ModelAndView fetchBook() {
		List<Book> listOfBooks = BookService.fetchBookList();
		System.out.println(listOfBooks);
		ModelAndView mv = new ModelAndView();
		mv.addObject("book_list", listOfBooks);
		mv.setViewName("AdminHome");
		
		return mv;
	}
	
	@RequestMapping("/Adminlogin")
	public ModelAndView Adminlogin() {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login");
		
		return mv;
	}
	
	
	@RequestMapping("/Usersignin1")
	public ModelAndView Usersignin1() {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Usersignin1");
		
		return mv;
	}
//	@RequestMapping("/adduserSignup")
//	public ModelAndView adduserSignup() {
////		List<Book> listOfBooks = BookService.fetchBookList();
////		System.out.println(listOfBooks);
//		ModelAndView mv = new ModelAndView();
////		mv.addObject("book_list", listOfBooks);
////		ModelAndView mv = new ModelAndView();
//		mv.setViewName("userhome1");
//		
//		return mv;
//	}
	
	@RequestMapping("/settings")
	public ModelAndView settings() {
		List<Book> listOfBooks = BookService.fetchBookList();
		System.out.println(listOfBooks);
		ModelAndView mv = new ModelAndView();
		mv.addObject("book_list", listOfBooks);
		
		mv.setViewName("bookhome");
		
		return mv;
	}
	
			
		@RequestMapping("/userbooklist")
	public ModelAndView userbooklist() {
			
				
			List<Book> listOfBooks = BookService.fetchBookList();
			System.out.println(listOfBooks);
			ModelAndView mv = new ModelAndView();
			mv.addObject("book_list", listOfBooks);
			
			
			
	mv.setViewName("userhome1");
	
	return mv;
	
}

	@RequestMapping("/cartpage")
	public ModelAndView cartpage() {
	
List<cartmodel> listOfBooks = cartservice.fetchcartList();
System.out.println(listOfBooks);
ModelAndView mv = new ModelAndView();
mv.addObject("book_list", listOfBooks);

	mv.setViewName("cartpage");
	
	return mv;
	
}
		
		

	
	
	
	@RequestMapping("/Adminsignup")
	public ModelAndView Adminsignup() {
		
		ModelAndView mv = new ModelAndView();
		
		mv.addObject("book_list", "listOfBooks");
		
		mv.setViewName("AdminSignup");
		
		return mv;
	}
	@RequestMapping("/Usersignup")
	public ModelAndView Usersignup() {
		
		ModelAndView mv = new ModelAndView();
		
		mv.addObject("book_list", "listOfBooks");
		
		mv.setViewName("Usersignup");
		
		return mv;
	}
	

	@RequestMapping("/editdelete")
	public ModelAndView editdelete() {
		List<Book> listOfBooks = BookService.fetchBookList();
		System.out.println(listOfBooks);
		ModelAndView mv = new ModelAndView();
		mv.addObject("book_list", listOfBooks);
		mv.addObject("success", "Book deleted successfully");

		
		mv.setViewName("EditDelete");
		
		return mv;
	}
	@RequestMapping("/updatebook")
	public ModelAndView updatebook(HttpServletRequest request, HttpServletResponse response) {
		boolean isBookAdded = BookService.updateBook(Integer.parseInt(request.getParameter("bookid")), request.getParameter("bookname"), request.getParameter("author"), Double.parseDouble(request.getParameter("bookprice")));
		
		ModelAndView mv = new ModelAndView();

		
		mv.addObject("success","Updated Successfully");
		mv.addObject("failure","Updated Failed");
		mv.setViewName("redirect:/fetchbook");
		
		return mv;
	}
	
	@RequestMapping("/deletebook")
	public ModelAndView deleteBook(HttpServletRequest request, HttpServletResponse response) {
		BookService.deleteBook(Integer.parseInt(request.getParameter("id")));
		
		ModelAndView mv = new ModelAndView();

		mv.setViewName("redirect:/fetchbook");
		
		return mv;
	}
	
	@RequestMapping("/deletecart")
	public ModelAndView deletecart(HttpServletRequest request, HttpServletResponse response) {
		cartservice.deletecart(Integer.parseInt(request.getParameter("id")));
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("success","Deleted from cart Successfully");
		mv.setViewName("userhome1");
		
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout() {
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("index");
		
		return mv;
	}

}

