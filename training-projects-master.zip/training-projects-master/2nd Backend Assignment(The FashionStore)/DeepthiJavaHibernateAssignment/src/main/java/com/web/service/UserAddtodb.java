package com.web.service;

import com.web.db.DBManager;
import com.web.model.userdetails;

public class UserAddtodb {
private static DBManager dbManager;
	
	static {
		dbManager = DBManager.getDBManager();
	}
	
	public static boolean adduser(String id, String name, String address,String phonenum, String password) {
		
		userdetails adduser = new userdetails();
		adduser.setUser_id(id);
		adduser.setUser_name(name);
		adduser.setUser_address(address);
		adduser.setUser_phno(phonenum);
		adduser.setUser_password(password);
		
		
		
		return dbManager.writeToDB(adduser);
	}
//	public static void main (String args[]) {
//		AdminSignupService u= new AdminSignupService();
//		u.addlibadmin(45, "user_name", "user_address", "user_phno");
//	}

}
