package com.web.service;

import com.web.db.DBManager;
import com.web.model.Book1;
import com.web.model.LibraryAdmin;

public class AdminSignupService {
private static DBManager dbManager;
	
	static {
		dbManager = DBManager.getDBManager();
	}
	
	public static boolean addlibadmin(int id, String name, String loginid, String password) {
		
		LibraryAdmin addlib = new LibraryAdmin();
		addlib.setId(id);
		addlib.setName(name);
		addlib.setLoginid(loginid);
		addlib.setPassword(password);
		
		return dbManager.writeToDB(addlib);
	}
//	public static void main (String args[]) {
//		AdminSignupService u= new AdminSignupService();
//		u.addlibadmin(45, "user_name", "user_address", "user_phno");
//	}

}
