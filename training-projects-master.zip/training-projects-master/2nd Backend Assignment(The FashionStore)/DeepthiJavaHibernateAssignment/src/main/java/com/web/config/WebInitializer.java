package com.web.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;


public class WebInitializer extends AbstractAnnotationConfigDispatcherServletInitializer  {
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		Class[] configClassList = new Class[] {WebConfig.class};
		return configClassList;
	}

	@Override
	protected String[] getServletMappings() {
		String[] mappingList = new String[] {"/"};
		return mappingList;
	}


}
