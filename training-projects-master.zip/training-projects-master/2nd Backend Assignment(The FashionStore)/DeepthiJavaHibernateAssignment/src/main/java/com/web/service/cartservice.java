package com.web.service;

import java.util.List;

import com.web.db.DBManager;
import com.web.model.Book1;
import com.web.model.cartmodel;

public class cartservice {
private static DBManager dbManager;
	
	static {
		dbManager = DBManager.getDBManager();
	}
	
	public static boolean addNewBook(int id, String name, String author, double price,String loggeduser) {
		System.out.println("Inside cart services");

		cartmodel insertcart = new cartmodel();
		insertcart.setId(id);
		insertcart.setBookName(name);
		insertcart.setAuthorName(author);
		insertcart.setBookPrice(price);
		insertcart.setLoggeduser(loggeduser);
		System.out.println("Added in to cart successfully");
		
		return dbManager.writeToDB(insertcart);
	}
	public static List fetchcartList() {
		System.out.println(dbManager.readFromDB("cartmodel"));
		return dbManager.readFromDB("cartmodel");
	}
	public static void deletecart(int id) {
		List<cartmodel> l = fetchcartList();
		cartmodel bookToDelete = null;
		for (cartmodel book : l) {
			if(book.getId() == id) {
				System.out.println(book.getId() + " :: " + id);
				bookToDelete = book;
				break;
			}
		}
		String name = bookToDelete.getBookName();
		String author = bookToDelete.getAuthorName();
		double price = bookToDelete.getBookPrice();
		
		cartmodel delcart = new cartmodel();
		delcart.setId(id);
		delcart.setBookName(name);
		delcart.setAuthorName(author);
		delcart.setBookPrice(price);
		
		dbManager.deleteFromDB(delcart);
	}
}
