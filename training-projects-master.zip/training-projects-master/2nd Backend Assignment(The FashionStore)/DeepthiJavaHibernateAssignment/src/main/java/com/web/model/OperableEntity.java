package com.web.model;


public abstract class OperableEntity {
	public int id;
	public abstract String toString();
}
