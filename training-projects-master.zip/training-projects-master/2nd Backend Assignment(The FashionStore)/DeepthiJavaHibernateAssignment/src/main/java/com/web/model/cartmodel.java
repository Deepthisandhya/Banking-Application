package com.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public  class cartmodel   extends OperableEntity {
	@Id
	public int id;
	public String bookName;
	public String authorName;
	public double bookPrice;
	public String loggeduser;
	public int getId() {
		return id;
	}
	public String getLoggeduser() {
		return loggeduser;
	}
	public void setLoggeduser(String loggeduser) {
		this.loggeduser = loggeduser;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	@Override
	public String toString() {
		return "cartmodel [id=" + id + ", bookName=" + bookName + ", authorName=" + authorName + ", bookPrice=" + bookPrice
				+ ", loggeduser=" + loggeduser +"]";
	}
}
