package com.web.controller;

import java.awt.print.Book;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.web.model.Book1;
import com.web.model.cartmodel;
import com.web.model.userdetails;
import com.web.service.BookService;
import com.web.service.cartservice;
@Controller
public class cartcontroller {

	@RequestMapping(value="/updatecart")
	public ModelAndView updatecart(HttpServletRequest request, HttpServletResponse response) {
	
cartservice.addNewBook(Integer.parseInt(request.getParameter("bookid")), request.getParameter("bookname"), request.getParameter("author"),
		Double.parseDouble(request.getParameter("bookprice")),request.getParameter("loggeduser"));

	
	System.out.println("Inside book controller");
	System.out.println(request.getParameter("actionForm"));
	
	
	List<cartmodel> listOfBooks = cartservice.fetchcartList();
	System.out.println(listOfBooks);
	ModelAndView mv = new ModelAndView();
	mv.addObject("book_list", listOfBooks);
	mv.addObject("loggeduser", request.getParameter("loggeduser"));
	
	
	

	
	mv.setViewName("cartpage");
	
	return mv;
	
}	

	
}
