package com.web.service;


import java.util.HashMap;
import java.util.List;

import com.web.db.DBManager;
import com.web.model.LibraryAdmin;

public abstract class UserService {
	static HashMap<String, String> userDetails = new HashMap<String, String>();


	private static DBManager dbManager;
	
	static {
		dbManager = DBManager.getDBManager();
	}
	
	@SuppressWarnings("unchecked")
	public static HashMap<String, String> validateAdmin (String uname, String pwd) {
		
		boolean isValidLogin = false;
		LibraryAdmin libraryAdmin = null;
		
		List<LibraryAdmin> adminList = dbManager.readFromDB("LibraryAdmin");

System.out.println("******"+adminList);
System.out.println("******"+uname);
		
		for(LibraryAdmin la : adminList) {
			if(la.getLoginid().equals(uname) && la.getPassword().equals(pwd)) {
				isValidLogin = true;
				libraryAdmin = la;
				break;
			} else {
				isValidLogin = false;
			}
		}
		
		if(isValidLogin) {
//			HashMap<String, String> userDetails = new HashMap<String, String>();
			userDetails.put("ADMIN_NAME", libraryAdmin.getName());
			System.out.println("user"+userDetails);
			return userDetails;
		}
		System.out.println("after if"+userDetails);
		return null;
		
		}
	
	
}
