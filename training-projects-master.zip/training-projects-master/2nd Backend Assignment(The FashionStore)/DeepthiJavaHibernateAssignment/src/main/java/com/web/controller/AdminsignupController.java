package com.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.web.service.AdminSignupService;

import com.web.service.BookService;

@Controller
public class AdminsignupController {


	@RequestMapping("/addAdminSignup")
	public ModelAndView addAdminSignup(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String loginid = request.getParameter("loginid");
		String password = request.getParameter("password");

		if(id.length()==0 || password.length()==0 || name.length()==0 || loginid.length()==0)  {
			
//			ModelAndView mv = new ModelAndView();
			mv.addObject("a_error", "Please enter the id");
			mv.setViewName("AdminSignup");
			mv.addObject("b_error", "Please enter the name");
			mv.setViewName("AdminSignup");
			mv.addObject("c_error", "Please enter the Username");
			mv.setViewName("AdminSignup");
			mv.addObject("d_error", "Please enter the password");
			mv.setViewName("AdminSignup");
			
			return mv;	
			
		}

		
		else {
		boolean isBookAdded = AdminSignupService.addlibadmin((Integer.parseInt(request.getParameter("id"))), request.getParameter("name"), request.getParameter("loginid"), request.getParameter("password"));
		try {
		if (isBookAdded) {
		

		mv.setViewName("login");
		return mv;
		}
		}
		catch(Exception e) {
			mv.addObject("msg", "Unable to add admin");
			mv.setViewName("login");
//			return mv;
			
			
		}
		
		return mv;
		
	}
}
}
