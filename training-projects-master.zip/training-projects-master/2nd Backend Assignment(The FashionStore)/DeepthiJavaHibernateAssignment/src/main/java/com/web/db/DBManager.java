package com.web.db;


import java.awt.print.Book;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.web.model.Book1;
import com.web.model.LibraryAdmin;
import com.web.model.userdetails;
import com.web.model.OperableEntity;


public class DBManager {

	private static class DB_SessionFactory {
		private Configuration config = null;
		private static SessionFactory sessionFactory;
		static {
			new DB_SessionFactory();
		}
		private DB_SessionFactory() {
			config = new Configuration().configure().addAnnotatedClass(LibraryAdmin.class).addAnnotatedClass(Book1.class);
			sessionFactory = config.buildSessionFactory();
		}
		public static SessionFactory getSessionFactory() {
			return sessionFactory;
		}
		
		public static void closeSessionFactory() {
				sessionFactory.close();
		}
	}
	
	private SessionFactory sessionFactory = null;
	private Session session = null;
	
	private static volatile DBManager dbManager = new DBManager();
	private DBManager() {
		sessionFactory = DB_SessionFactory.getSessionFactory();
	}
	
	public static DBManager getDBManager() { return dbManager; }
	
	public void writeToDB(List<OperableEntity> entities) {
		try {
			if (entities.isEmpty())
				throw new Exception();
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			for (OperableEntity entity : entities)
				session.save(entity);
			transaction.commit();
		} catch(Exception e) {
			System.err.println("ERROR in Write Operation on Database");
		} finally {
			session.close();
		}
	}
	
	public boolean writeToDB(OperableEntity entity) {
		boolean isWriteSuccessful = false;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.saveOrUpdate(entity);
			transaction.commit();
			isWriteSuccessful = true;
		} catch(Exception e) {
			System.err.println("ERROR in Write Operation on Database");
			e.printStackTrace();
		} finally {
			session.close();
		}
		return isWriteSuccessful;
	}
	
	public List writeToDBcart(String book) {
		boolean isWriteSuccessful = false;
		List list = null;
		System.out.println("********* book"+book);
//		try {
//			session = sessionFactory.openSession();
//			Transaction transaction = session.beginTransaction();
//			Query readQuery = session.createQuery("from " + modelName);
//			list = readQuery.list();
//			transaction.commit();
//		} catch(Exception e) {
//			e.printStackTrace();
//			System.err.println("ERROR in Read Operation on Database");
//		} finally {
//			session.close();
//		}
//		
		return list;
	}
	
	@SuppressWarnings("rawtypes")
	public List readFromDB(String modelName) {
		List list = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			Query readQuery = session.createQuery("from " + modelName);
			list = readQuery.list();
			transaction.commit();
		} catch(Exception e) {
			e.printStackTrace();
			System.err.println("ERROR in Read Operation on Database");
		} finally {
			session.close();
		}
		
		return list;
	}
	
	public List readFromDBSpecific(String name1) {
		String modelName="Book1";
		List list = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			System.out.println("from " + modelName+" where bookName='"+name1+"'");
			Query readQuery = session.createQuery("from " + modelName+" where bookName='"+name1+"'");
			list = readQuery.list();
			transaction.commit();
		} catch(Exception e) {
			e.printStackTrace();
			System.err.println("ERROR in Read Operation on Database");
		} finally {
			session.close();
		}
		
		return list;
	}
	
	public void deleteFromDB(OperableEntity entity) {
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.delete(entity);
			transaction.commit();
		} catch(Exception e) {
			System.err.println("ERROR in Delete Operation on Database");
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
}

