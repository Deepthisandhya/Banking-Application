package com.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.web.model.userdetails;

import com.web.service.UserAddtodb;
@Controller
public class usersignupcontroller {

	@RequestMapping(value="/adduserSignup")
	public ModelAndView adduserSignup(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		String user_id = request.getParameter("user_id");
		String user_name = request.getParameter("user_name");
		String user_address = request.getParameter("user_address");
		String user_phno = request.getParameter("user_phno");
		String user_password = request.getParameter("user_password");

		if(user_id.length()==0 || user_name.length()==0 || user_address.length()==0 || user_phno.length()==0 || user_password.length()==0)  {
			
//			ModelAndView mv = new ModelAndView();
			mv.addObject("a_error", "Please enter the user id");
			mv.setViewName("Usersignup");
			mv.addObject("b_error", "Please enter the user name");
			mv.setViewName("Usersignup");
			mv.addObject("c_error", "Please enter the address");
			mv.setViewName("Usersignup");
			mv.addObject("d_error", "Please enter the phone number");
			mv.setViewName("Usersignup");
			mv.addObject("e_error", "Please enter the password");
			mv.setViewName("Usersignup");
			
			
			return mv;	
			
		}

		
		else {
		boolean isBookAdded = UserAddtodb.adduser(request.getParameter("user_id"), request.getParameter("user_name"), request.getParameter("user_address"), request.getParameter("user_phno"), request.getParameter("user_password"));
		try {
		if (isBookAdded) {
		

		mv.setViewName("Usersignin1");
		return mv;
		}
		}
		catch(Exception e) {
			mv.addObject("msg", "Unable to add admin");
			mv.setViewName("login");
//			return mv;
			
			
		}
		
		return mv;
		
	}
}
}
