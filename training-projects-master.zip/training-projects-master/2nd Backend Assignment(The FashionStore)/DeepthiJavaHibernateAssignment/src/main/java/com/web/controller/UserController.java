package com.web.controller;


import java.util.Enumeration;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.service.UserService;


@Controller
public class UserController {
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		
		String username = request.getParameter("uname");
		String password = request.getParameter("pwd");

		if(username.length()==0 || password.length()==0)  {
			
			ModelAndView mv = new ModelAndView();
			mv.addObject("u_error", "Please enter the Username");
			mv.setViewName("index");
			mv.addObject("p_error", "Please enter the Password");
		mv.setViewName("index");
			
			return mv;	
			
		}

		
		else {
		Map<String, String> userDetails = UserService.validateAdmin(username, password);
		
		try {
			String userFullName = userDetails.get("ADMIN_NAME");

			request.getSession().setAttribute("USER_FULL_NAME", userFullName);
			ModelAndView mv = new ModelAndView();
			mv.setViewName("redirect:/fetchbook");	
//			mv.setViewName("bookhome");
			
			return mv;
		} catch (Exception e) {
			ModelAndView mv = new ModelAndView();
			mv.addObject("msg", "Username/Password is wrong");
			mv.setViewName("index");
			
			return mv;
		}
		
		}
	}
	
//	@RequestMapping("/register")
//	public String register(HttpServletRequest request, HttpServletResponse response) {
//
//		Enumeration<String> params = request.getParameterNames();
//		
//		while(params.hasMoreElements()) {
//			String currentParam = params.nextElement();
//			String currentVal = request.getParameter(currentParam);
//			System.out.println(currentParam + "=" + currentVal);
//		}
//		
//		return "file2";
//	}

}
