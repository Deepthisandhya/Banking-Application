
      
function onButtonClick(){
  document.getElementById('myInput').className="show";
  document.getElementById('myInput1').className="show";

}
function onButtonClick1(){
  document.getElementById('myInput2').className="show";
  document.getElementById('myInput3').className="show";
  document.getElementById('myInput').className="hide";
  document.getElementById('myInput1').className="hide";

}

// Create a "close" button and append it to each list item
var myNodelist = document.getElementsByTagName("LI");
var i;
for (i = 0; i < myNodelist.length; i++) {
  // creating checkbox element 
  var checkbox = document.createElement('input'); 
  checkbox.className="close";           
  // Assigning the attributes 
  // to created checkbox 
  checkbox.type = "checkbox"; 
  checkbox.name = "name"; 
  checkbox.value = "value"; 
  checkbox.id = "checkid"; 
    

  myNodelist[i].appendChild(checkbox); 
//   myNodelist[i].appendChild(span);
}
  function deletelist(){
var boxes = document.getElementsByClassName('close');
  console.log(boxes);
  var div = document.getElementsByClassName('listele');
  console.log(div);

  for(var i = 0; i<boxes.length; i++){
      box = boxes[i];
      div = div[i];
      if(box.checked){
          box.parentNode.removeChild(box);
          div.parentNode.removeChild(div);
      }
  }
  }
  function editlist(){
    var boxes = document.getElementsByClassName('close');
      console.log(boxes);
      var div = document.getElementsByClassName('listele');
      console.log(div);
    
      for(var i = 0; i<boxes.length; i++){
          box = boxes[i];
          div = div[i];
          if(box.checked){
            var inputValue = document.getElementById("myInput2").value;
            div.innerHTML=inputValue;

  //           console.log(inputValue);
  // var t = document.createTextNode(inputValue);
  // console.log(t);

  // var aa=li.appendChild(t);
  // console.log(aa);

  if (inputValue === '') {
    alert("You must write something!");
  } else {
      alert(inputValue+" added successfully in to the list")
    // document.getElementById("mylist").appendChild(li);
  }

              
          }
      }
      
      document.getElementById("myInput2").value = "";
 var myNodelist = document.getElementsByTagName("LI");
var i;
for (i = 0; i < myNodelist.length; i++) {
  // creating checkbox element 
  var checkbox = document.createElement('input'); 
              
  // Assigning the attributes 
  // to created checkbox 
  checkbox.className="close"
  checkbox.type = "checkbox"; 
  checkbox.name = "name"; 
  checkbox.value = "value"; 
  checkbox.id = "checkid"; 
    

  myNodelist[i].appendChild(checkbox)
}
  }
// Create a new list item when clicking on the "Add" button
function newElement() {
  var li = document.createElement("li");
  li.className="listele";
  var inputValue = document.getElementById("myInput").value;
  var t = document.createTextNode(inputValue);
  li.appendChild(t);

  if (inputValue === '') {
    alert("You must write something!");
  } else {
      alert(inputValue+" added successfully in to the list")
    document.getElementById("mylist").appendChild(li);
  }
 document.getElementById("myInput").value = "";
 var myNodelist = document.getElementsByTagName("LI");
var i;
for (i = 0; i < myNodelist.length; i++) {
  // creating checkbox element 
  var checkbox = document.createElement('input'); 
              
  // Assigning the attributes 
  // to created checkbox 
  checkbox.className="close"
  checkbox.type = "checkbox"; 
  checkbox.name = "name"; 
  checkbox.value = "value"; 
  checkbox.id = "checkid"; 
    

  myNodelist[i].appendChild(checkbox); 

}
}

