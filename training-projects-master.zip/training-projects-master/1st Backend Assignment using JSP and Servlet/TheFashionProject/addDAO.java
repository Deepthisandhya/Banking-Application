package TheFashionProject;

import java.sql.Connection;
import java.sql.Statement;

import com.LoginForm.jdbconnection;

public class addDAO {
	public void addarray(String addarray,String priceoption) {
		jdbconnection jdbc1 = new jdbconnection();
		Connection con=jdbc1.getcon();
		
		
		
		
		
		

			
					  try {

							 String query = "INSERT INTO Fashion_Store.add(add_dress,add_price) VALUES ('"+addarray+"','"+priceoption+"');";

					    // set all the preparedstatement parameters
					   Statement st = con.createStatement();
					   st.executeUpdate(query); 
					   
					    }catch(Exception e){
							System.out.println(e.getMessage());
						}
	}
	
	public void editarray(String addarray,String priceoption,String dress) {
		jdbconnection jdbc1 = new jdbconnection();
		Connection con=jdbc1.getcon();
		
		
		
		
		
		

			
					  try {
						  String query = "UPDATE Fashion_Store.add SET add_dress='"+addarray+"', add_price='"+priceoption+"' WHERE add_dress='"+dress+"';";
							 

					    // set all the preparedstatement parameters
					   Statement st = con.createStatement();
					   st.executeUpdate(query); 
					   
					    }catch(Exception e){
							System.out.println(e.getMessage());
						}
	}
	
	public void deletearray(String dress) {
		jdbconnection jdbc1 = new jdbconnection();
		Connection con=jdbc1.getcon();
		
		
		
		
		
		

			
					  try {
						  String query = "DELETE from Fashion_Store.add WHERE add_dress='"+dress+"';";
							 

					    // set all the preparedstatement parameters
					   Statement st = con.createStatement();
					   st.executeUpdate(query); 
					   
					    }catch(Exception e){
							System.out.println(e.getMessage());
						}
	}

}
