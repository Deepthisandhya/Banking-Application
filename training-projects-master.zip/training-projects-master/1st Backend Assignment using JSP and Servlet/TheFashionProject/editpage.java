package TheFashionProject;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class editpage
 */
@WebServlet("/editpage")
public class editpage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String gender=request.getParameter("gender");
		if(gender.contains("Men")) {
			String dressoption=request.getParameter("addoption");
			String priceoption=request.getParameter("priceoption");
			
			String selecteddress = request.getParameter("dress");
		
		
		addDAO dao=new addDAO();
				
				dao.editarray(dressoption,priceoption,selecteddress);
				addgetsql list1=new addgetsql();
				
				ArrayList <String> dress=list1.getdressdetails();
						
						ArrayList <String> price=list1.getpricedetails();
		
	
		

//		ArrayList <String> myArray = new ArrayList<String>(Arrays.asList("jean","jupa","Shirt","shorts"));
//		myArray.addAll(a);
	
		
		request.setAttribute("dress", dress);
		request.setAttribute("price", price);
		System.out.println("Success");

				

		
		
			request.getRequestDispatcher("secondpage.jsp").forward(request,response);
		}
		else {
			String dressoption=request.getParameter("addoption");
			String priceoption=request.getParameter("priceoption");
			
			String selecteddress = request.getParameter("dress");
			addDAOWomen daoWomen=new addDAOWomen();
			
			daoWomen.editarray(dressoption,priceoption,selecteddress);
						addgetsqlwomen list1=new addgetsqlwomen();

				ArrayList <String> dress=list1.getdressdetails();
				
				ArrayList <String> price=list1.getpricedetails();
				



				
				request.setAttribute("dress", dress);
				request.setAttribute("price", price);
				System.out.println("Success");


				
				
					request.getRequestDispatcher("thirdpage.jsp").forward(request,response);

		}
			
	
	}


	}


