package TheFashionProject;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class deletepage
 */
@WebServlet("/deletepage")
public class deletepage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
		String selecteddress = request.getParameter("dress");
		
		
		addDAO dao=new addDAO();
				
				dao.deletearray(selecteddress);
				addgetsql list1=new addgetsql();
				
				ArrayList <String> dress=list1.getdressdetails();
						
						ArrayList <String> price=list1.getpricedetails();
		
	
		

//		ArrayList <String> myArray = new ArrayList<String>(Arrays.asList("jean","jupa","Shirt","shorts"));
//		myArray.addAll(a);
	
		
		request.setAttribute("dress", dress);
		request.setAttribute("price", price);
		System.out.println("Success");

				

		
		
			request.getRequestDispatcher("secondpage.jsp").forward(request,response);
			
			
	
	}



	}

