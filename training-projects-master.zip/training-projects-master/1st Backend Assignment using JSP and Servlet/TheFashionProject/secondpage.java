package TheFashionProject;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class secondpage
 */
@WebServlet("/secondpage")
public class secondpage extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String gender=request.getParameter("gender");

		if(gender.contains("Men")) {
			String addoption=request.getParameter("addoption");
			String priceoption=request.getParameter("priceoption");
			
			addDAO dao=new addDAO();
			
			dao.addarray(addoption,priceoption);
	addgetsql list1=new addgetsql();

	ArrayList <String> dress=list1.getdressdetails();
	
	ArrayList <String> price=list1.getpricedetails();



	
	request.setAttribute("dress", dress);
	request.setAttribute("price", price);
	System.out.println("Success");


	
	
		request.getRequestDispatcher("secondpage.jsp").forward(request,response);
		}
		
		else {
			String addoption=request.getParameter("addoption");
			String priceoption=request.getParameter("priceoption");
addDAOWomen daoWomen=new addDAOWomen();
			
daoWomen.addarray(addoption,priceoption);
			addgetsqlwomen list1=new addgetsqlwomen();

	ArrayList <String> dress=list1.getdressdetails();
	
	ArrayList <String> price=list1.getpricedetails();



	
	request.setAttribute("dress", dress);
	request.setAttribute("price", price);
	System.out.println("Success");


	
	
		request.getRequestDispatcher("thirdpage.jsp").forward(request,response);

		}
			
			
	
	}

	}

