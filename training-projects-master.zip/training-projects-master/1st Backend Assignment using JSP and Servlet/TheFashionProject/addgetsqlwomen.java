package TheFashionProject;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.LoginForm.jdbconnection;

public class addgetsqlwomen {
	public ArrayList<String> getdressdetails() {
		jdbconnection jdbc1 = new jdbconnection();
		Connection con=jdbc1.getcon();
		ArrayList<String> dress=new ArrayList<String>();
		ArrayList<String> signuparray=new ArrayList<String>();



		try {

	String query="Select * from Fashion_Store.add;";
		  
	   Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);
//		rs.getMetaData();
		while(rs.next()) {
			dress.add(rs.getString("add_dress"));
			
		}

		System.out.println(dress.get(1));
	}catch(Exception e) {

	}
		return dress;
		
	}
		
		public ArrayList<String> getpricedetails() {
			jdbconnection jdbc1 = new jdbconnection();
			Connection con=jdbc1.getcon();
			ArrayList<String> price=new ArrayList<String>();
			ArrayList<String> signuparray=new ArrayList<String>();



			try {

		String query="Select * from Fashion_Store.add;";
			  
		   Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
//			rs.getMetaData();
			while(rs.next()) {
				price.add(rs.getString("add_price"));
			}

			System.out.println(price.get(1));
		}catch(Exception e) {

		}
			return price;
			
		}


}
